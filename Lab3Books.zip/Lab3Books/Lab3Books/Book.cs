﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab3Books
{
    public class Book
    {
        public string Title { get; set; }
        public int TotalPages { get; set; }
        public int FilledPages { get; set; }

        public Book(string title, int totalPages)
        {
            Title = title;
            TotalPages = totalPages;
            FilledPages = 0;
        }

        public void Write(int pagesToWrite)
        {
            if (FilledPages + pagesToWrite > TotalPages)
            {
                Console.WriteLine("Error: Not enough space in the book to write.");
            }
            else
            {
                FilledPages += pagesToWrite;
                Console.WriteLine("{0} pages written. The book now has {1} filled pages.", pagesToWrite, FilledPages);
            }
        }

        public double GetFillPercentage()
        {
            return (double)FilledPages / TotalPages * 100;
        }

        public void Erase()
        {
            FilledPages = 0;
            Console.WriteLine("All pages erased from the book.");
        }
    }
}