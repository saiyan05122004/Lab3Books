﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab3Books
{
    public partial class Form1 : Form
    {
        private Book book;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnInitialize_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtTotalPages.Text, out int totalPages))
            {
                book = new Book(txtTitle.Text, totalPages);
                UpdateUI();
            }
            else
            {
                MessageBox.Show("Введите корректное число страниц");
            }
        }

        private void btnWrite_Click(object sender, EventArgs e)
        {
            if (book == null)
            {
                MessageBox.Show("Сначала создайте книгу");
            }
            else if (int.TryParse(txtPagesToWrite.Text, out int pagesToWrite))
            {
                book.Write(pagesToWrite);
                UpdateUI();
            }
            else
            {
                MessageBox.Show("Введите корректное число страниц для записи");
            }
        }

        private void btnErase_Click(object sender, EventArgs e)
        {
            if (book == null)
            {
                MessageBox.Show("Сначала создайте книгу");
            }
            else
            {
                DialogResult result = MessageBox.Show("Подтверждение удаления", "Подтверждение", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    book.Erase();
                    UpdateUI();
                }
            }
        }

        private void btnShowTotalPagesWritten_Click(object sender, EventArgs e)
        {
            if (book == null)
            {
                MessageBox.Show("Сначала создайте книгу");
            }
            else
            {
                MessageBox.Show(string.Format("Общее число записей в книге: {0}", book.FilledPages));
            }
        }

        private void UpdateUI()
        {
            if (book != null)
            {
                lblTitle.Text = book.Title;
                lblTotalPages.Text = book.TotalPages.ToString();
                lblFilledPages.Text = book.FilledPages.ToString();
                double fillPercentage = book.GetFillPercentage();
                progBarFillPercentage.Value = (int)fillPercentage;
                lblFillPercentage.Text = string.Format("{0:0.00}%", fillPercentage);
            }
            else
            {
                lblTitle.Text = "";
                lblTotalPages.Text = "";
                lblFilledPages.Text = "";
                progBarFillPercentage.Value = 0;
                lblFillPercentage.Text = "";
            }
        }
    }
}