﻿namespace Lab3Books
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblTotalPagesText = new System.Windows.Forms.Label();
            this.lblFilledPagesText = new System.Windows.Forms.Label();
            this.lblFillPercentageText = new System.Windows.Forms.Label();
            this.txtTitle = new System.Windows.Forms.TextBox();
            this.txtTotalPages = new System.Windows.Forms.TextBox();
            this.btnInitialize = new System.Windows.Forms.Button();
            this.txtPagesToWrite = new System.Windows.Forms.TextBox();
            this.btnWrite = new System.Windows.Forms.Button();
            this.btnErase = new System.Windows.Forms.Button();
            this.progBarFillPercentage = new System.Windows.Forms.ProgressBar();
            this.lblTotalPages = new System.Windows.Forms.Label();
            this.lblFilledPages = new System.Windows.Forms.Label();
            this.lblFillPercentage = new System.Windows.Forms.Label();
            this.btnShowTotalPagesWritten = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Location = new System.Drawing.Point(12, 21);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(57, 13);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Название";
            // 
            // lblTotalPagesText
            // 
            this.lblTotalPagesText.AutoSize = true;
            this.lblTotalPagesText.Location = new System.Drawing.Point(12, 48);
            this.lblTotalPagesText.Name = "lblTotalPagesText";
            this.lblTotalPagesText.Size = new System.Drawing.Size(110, 13);
            this.lblTotalPagesText.TabIndex = 1;
            this.lblTotalPagesText.Text = "Количество страниц";
            // 
            // lblFilledPagesText
            // 
            this.lblFilledPagesText.AutoSize = true;
            this.lblFilledPagesText.Location = new System.Drawing.Point(12, 75);
            this.lblFilledPagesText.Name = "lblFilledPagesText";
            this.lblFilledPagesText.Size = new System.Drawing.Size(128, 13);
            this.lblFilledPagesText.TabIndex = 2;
            this.lblFilledPagesText.Text = "Заполненные страницы";
            // 
            // lblFillPercentageText
            // 
            this.lblFillPercentageText.AutoSize = true;
            this.lblFillPercentageText.Location = new System.Drawing.Point(12, 102);
            this.lblFillPercentageText.Name = "lblFillPercentageText";
            this.lblFillPercentageText.Size = new System.Drawing.Size(113, 13);
            this.lblFillPercentageText.TabIndex = 3;
            this.lblFillPercentageText.Text = "Процент заполнения";
            // 
            // txtTitle
            // 
            this.txtTitle.Location = new System.Drawing.Point(101, 18);
            this.txtTitle.Name = "txtTitle";
            this.txtTitle.Size = new System.Drawing.Size(155, 20);
            this.txtTitle.TabIndex = 4;
            // 
            // txtTotalPages
            // 
            this.txtTotalPages.Location = new System.Drawing.Point(128, 45);
            this.txtTotalPages.Name = "txtTotalPages";
            this.txtTotalPages.Size = new System.Drawing.Size(100, 20);
            this.txtTotalPages.TabIndex = 5;
            // 
            // btnInitialize
            // 
            this.btnInitialize.Location = new System.Drawing.Point(262, 18);
            this.btnInitialize.Name = "btnInitialize";
            this.btnInitialize.Size = new System.Drawing.Size(75, 47);
            this.btnInitialize.TabIndex = 6;
            this.btnInitialize.Text = "Создать книгу";
            this.btnInitialize.UseVisualStyleBackColor = true;
            this.btnInitialize.Click += new System.EventHandler(this.btnInitialize_Click);
            // 
            // txtPagesToWrite
            // 
            this.txtPagesToWrite.Location = new System.Drawing.Point(101, 132);
            this.txtPagesToWrite.Name = "txtPagesToWrite";
            this.txtPagesToWrite.Size = new System.Drawing.Size(100, 20);
            this.txtPagesToWrite.TabIndex = 7;
            // 
            // btnWrite
            // 
            this.btnWrite.Location = new System.Drawing.Point(207, 130);
            this.btnWrite.Name = "btnWrite";
            this.btnWrite.Size = new System.Drawing.Size(75, 23);
            this.btnWrite.TabIndex = 8;
            this.btnWrite.Text = "Написать";
            this.btnWrite.UseVisualStyleBackColor = true;
            this.btnWrite.Click += new System.EventHandler(this.btnWrite_Click);
            // 
            // btnErase
            // 
            this.btnErase.Location = new System.Drawing.Point(207, 159);
            this.btnErase.Name = "btnErase";
            this.btnErase.Size = new System.Drawing.Size(75, 23);
            this.btnErase.TabIndex = 9;
            this.btnErase.Text = "Очистить";
            this.btnErase.UseVisualStyleBackColor = true;
            this.btnErase.Click += new System.EventHandler(this.btnErase_Click);
            // 
            // progBarFillPercentage
            // 
            this.progBarFillPercentage.Location = new System.Drawing.Point(127, 101);
            this.progBarFillPercentage.Name = "progBarFillPercentage";
            this.progBarFillPercentage.Size = new System.Drawing.Size(155, 23);
            this.progBarFillPercentage.TabIndex = 10;
            // 
            // lblTotalPages
            // 
            this.lblTotalPages.AutoSize = true;
            this.lblTotalPages.Location = new System.Drawing.Point(146, 75);
            this.lblTotalPages.Name = "lblTotalPages";
            this.lblTotalPages.Size = new System.Drawing.Size(13, 13);
            this.lblTotalPages.TabIndex = 11;
            this.lblTotalPages.Text = "0";
            // 
            // lblFilledPages
            // 
            this.lblFilledPages.AutoSize = true;
            this.lblFilledPages.Location = new System.Drawing.Point(125, 102);
            this.lblFilledPages.Name = "lblFilledPages";
            this.lblFilledPages.Size = new System.Drawing.Size(13, 13);
            this.lblFilledPages.TabIndex = 12;
            this.lblFilledPages.Text = "0";
            // 
            // lblFillPercentage
            // 
            this.lblFillPercentage.AutoSize = true;
            this.lblFillPercentage.Location = new System.Drawing.Point(98, 129);
            this.lblFillPercentage.Name = "lblFillPercentage";
            this.lblFillPercentage.Size = new System.Drawing.Size(21, 13);
            this.lblFillPercentage.TabIndex = 13;
            this.lblFillPercentage.Text = "0%";
            // 
            // btnShowTotalPagesWritten
            // 
            this.btnShowTotalPagesWritten.Location = new System.Drawing.Point(101, 159);
            this.btnShowTotalPagesWritten.Name = "btnShowTotalPagesWritten";
            this.btnShowTotalPagesWritten.Size = new System.Drawing.Size(100, 23);
            this.btnShowTotalPagesWritten.TabIndex = 14;
            this.btnShowTotalPagesWritten.Text = "Показать общее число заполненных страниц";
            this.btnShowTotalPagesWritten.UseVisualStyleBackColor = true;
            this.btnShowTotalPagesWritten.Click += new System.EventHandler(this.btnShowTotalPagesWritten_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(349, 199);
            this.Controls.Add(this.btnShowTotalPagesWritten);
            this.Controls.Add(this.lblFillPercentage);
            this.Controls.Add(this.lblFilledPages);
            this.Controls.Add(this.lblTotalPages);
            this.Controls.Add(this.progBarFillPercentage);
            this.Controls.Add(this.btnErase);
            this.Controls.Add(this.btnWrite);
            this.Controls.Add(this.txtPagesToWrite);
            this.Controls.Add(this.btnInitialize);
            this.Controls.Add(this.txtTotalPages);
            this.Controls.Add(this.txtTitle);
            this.Controls.Add(this.lblFillPercentageText);
            this.Controls.Add(this.lblFilledPagesText);
            this.Controls.Add(this.lblTotalPagesText);
            this.Controls.Add(this.lblTitle);
            this.Name = "Form1";
            this.Text = "Book Application";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblTotalPagesText;
        private System.Windows.Forms.Label lblFilledPagesText;
        private System.Windows.Forms.Label lblFillPercentageText;
        private System.Windows.Forms.TextBox txtTitle;
        private System.Windows.Forms.TextBox txtTotalPages;
        private System.Windows.Forms.Button btnInitialize;
        private System.Windows.Forms.TextBox txtPagesToWrite;
        private System.Windows.Forms.Button btnWrite;
        private System.Windows.Forms.Button btnErase;
        private System.Windows.Forms.ProgressBar progBarFillPercentage;
        private System.Windows.Forms.Label lblTotalPages;
        private System.Windows.Forms.Label lblFilledPages;
        private System.Windows.Forms.Label lblFillPercentage;
        private System.Windows.Forms.Button btnShowTotalPagesWritten;
    }
}